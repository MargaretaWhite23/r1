rm *.tar
tar cf kernel.tar -C ~/kernel/linux-source-5.18 arch/x86/kvm/vmx/vmx.c
tar cf qemu.tar -C ~/qemu/qemu-7.0.0 hw/ide/core.c
tar cf ovmf.tar -C ~/edk2/edk2/ OvmfPkg/SmbiosPlatformDxe/SmbiosPlatformDxe.c
tar rf qemu.tar -C ~/qemu/qemu-7.0.0 roms/ipxe/src/drivers/net/pnic.c
tar rf qemu.tar -C ~/qemu/qemu-7.0.0 hw/ide/atapi.c
tar rf qemu.tar -C ~/qemu/qemu-7.0.0 hw/scsi/scsi-disk.c
tar rf qemu.tar -C ~/qemu/qemu-7.0.0 block/bochs.c
tar rf qemu.tar -C ~/qemu/qemu-7.0.0 target/i386/kvm/kvm.c
tar rf qemu.tar -C ~/qemu/qemu-7.0.0 hw/usb/dev-wacom.c
